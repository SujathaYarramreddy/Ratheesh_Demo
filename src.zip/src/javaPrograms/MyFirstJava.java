package javaPrograms;

public class MyFirstJava {

	
	static int i=10;
	static int j=20;
	static int k;
	
	// operaters +,-,*,%,/
	int multiply() {
		
		return k=i*j;
		
	}
	
	
	
	public static void main(String[] args) {
		
		
		
		MyFirstJava obj = new MyFirstJava();
		
		System.out.println(obj.multiply());
		
	}
	
	
	
	
}
