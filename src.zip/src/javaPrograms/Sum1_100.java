package javaPrograms;

public class Sum1_100 {
	
	static int i=10;
	static int j=20;
	
	public static void main(String[] args) {
		
/*		i++;
		j--;
		
		System.out.println(i); //11
		System.out.println(j); //19
		
		++i;
		--j;
		System.out.println(i); //12
		System.out.println(j); //18
		
		
		int k = ++i + --j;
		
		System.out.println(k); //k = 30, 
		
		int l = i++ + j--; 
		
		System.out.println(l); //30
*/		
		
		//System.out.println(++i + --j); 
		
		
	//	System.out.println(i++ + --j);
	
		
		/*for(int i;con;) {
			
		}*/
		
		
		//sum of 1 to 100
		int k=0;
		for(int i=1,  j=1  ;i<=3;i++) {
			
			j++;
			k=i+j;		
		}
		
		
		
		System.out.println(k);
		
		
		
		
		
		
		
	}
}
